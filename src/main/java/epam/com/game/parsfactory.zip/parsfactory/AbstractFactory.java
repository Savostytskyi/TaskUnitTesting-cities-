package epam.com.game.parsfactory;

import java.util.ArrayList;

public abstract class AbstractFactory {
	public ArrayList<String> cities = new ArrayList<String>();
		
		public abstract ArrayList cityesDocumentParser();
}
